full_version = "7.3.2"
short_version = ".".join(full_version.split(".", 2)[:2])
